package main;

import java.sql.SQLException;
import view.login.LoginVIEW;

public class TesteAcessoBD {

    public static void main(String[] args) throws SQLException {

        LoginVIEW loginTela = new LoginVIEW();
        loginTela.setVisible(true);
        loginTela.pack();
        loginTela.setLocationRelativeTo(null);

    }
}
