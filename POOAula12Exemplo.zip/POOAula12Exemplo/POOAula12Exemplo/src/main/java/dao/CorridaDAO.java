package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Corrida;
import model.Motorista;
import model.Usuario;

/**
 *
 * @author Tatiana
 */
public class CorridaDAO {

    private Connection conn;

    public CorridaDAO() {
        conn = ConnectionFactory.getConnection();

    }

    public void inserir(Corrida corrida) {
        try {
            String sql = "insert into corrida(user_id,motorista_id,origem,destino) values (?,?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, corrida.getUser().getId());
            stmt.setInt(2, corrida.getMotorista().getId());
            stmt.setString(3, corrida.getOrigem());
            stmt.setString(4, corrida.getDestino());
            stmt.execute();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(CorridaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void editar(Corrida corrida) {

        try {
            String sql = "update corrida set user_id = ?, motorista_id = ?, origem = ?, destino = ? where id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, corrida.getUser().getId());
            stmt.setInt(2, corrida.getMotorista().getId());
            stmt.setString(3, corrida.getOrigem());
            stmt.setString(4, corrida.getDestino());
            stmt.setInt(5, corrida.getId());
            stmt.execute();
            stmt.close();
        } catch (SQLException ex) {

            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE,
                    null, ex);
        }
    }

    public ArrayList<Corrida> selecionar() {

        ArrayList<Usuario> users = new ArrayList<>();
        ArrayList<Corrida> listaCorrida = new ArrayList<>();
        ArrayList<Motorista> motoristas = new ArrayList<>();

        UsuarioDAO userDAO = new UsuarioDAO();
        MotoristaDAO motoristaDAO = new MotoristaDAO();

        users = userDAO.selecionar();
        motoristas = motoristaDAO.selecionar();

        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from corrida");

            while (rs.next()) {
                int corridaId = rs.getInt("id");
                int userId = rs.getInt("user_id");
                int motoristaID = rs.getInt("motorista_id");
                String origem = rs.getString("origem");
                String destino = rs.getString("destino");

                Motorista motorista = null;
                Usuario usuario = null;

                for (Usuario u : users) {
                    if (u.getId() == userId) {
                        usuario = u;
                        break;
                    }
                }

                for (Motorista m : motoristas) {
                    if (m.getId() == motoristaID) {
                        motorista = m;
                        break;
                    }
                }

                Corrida corrida = new Corrida(corridaId, usuario, origem, destino, motorista);
                listaCorrida.add(corrida);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaCorrida;
    }

    public Corrida selecionarPorID(int id) {
        Corrida corrida = null;
        ArrayList<Usuario> users = new ArrayList<>();
        ArrayList<Motorista> motoristas = new ArrayList<>();

        MotoristaDAO motoristaDAO = new MotoristaDAO();
        UsuarioDAO userDAO = new UsuarioDAO();

        users = userDAO.selecionar();
        motoristas = motoristaDAO.selecionar();

        try {

            PreparedStatement stmt = conn.prepareStatement("select * from Corrida where id = ?");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int corridaId = rs.getInt("id");
                int userId = rs.getInt("user_id");
                int motoristaID = rs.getInt("motorista_id");
                String origem = rs.getString("origem");
                String destino = rs.getString("destino");

                Motorista motorista = new Motorista();
                Usuario usuario = new Usuario();

                for (Usuario u : users) {
                    if (u.getId() == userId) {
                        usuario = u;
                        break;
                    }
                }

                for (Motorista m : motoristas) {
                    if (m.getId() == motoristaID) {
                        motorista = m;
                        break;
                    }
                }

                corrida = new Corrida(corridaId, usuario, origem, destino, motorista);

            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return corrida;

    }

    public void excluir(int id) {

        try {
            String sql = "delete from corrida where id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.execute();
            stmt.close();

        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE,
                    null, ex);
        }
    }
}
